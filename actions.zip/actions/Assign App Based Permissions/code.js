/**
* Handler that will be called during the execution of a PostLogin flow.
*
* @param {Event} event - Details about the user and the context in which they are logging in.
* @param {PostLoginAPI} api - Interface whose methods can be used to change the behavior of the login.
*/
exports.onExecutePostLogin = async (event, api) => {

  // check if the app based permission variable is set for the user 
  if(event.user.app_metadata.evaluate_app_roles){
    // if it's set to evaluate application based roles, get the defined roles in Auth0 and map them to 
    // the access token and id token 

    // to do this, we need the ManagmentAPI 
      const MgmtClient = require('auth0').ManagementClient; 
      const client = new MgmtClient({
          domain: event.secrets.domain, 
          clientId: event.secrets.clientId, 
          clientSecret: event.secrets.clientSecret
      })

      // get the permissions for a given role, the role is indexed by the application name 
      // we're just going to have a hardcoded swap here, but ideally this can be done with a mapping 

      let targetRole = "";

      if(event.client.name == "CIBT Passports"){
          targetRole = 'rol_vyrM6EuT3XIXQWrY';

      }else if(event.client.name == "CIBT Visas"){
          targetRole = 'rol_ViHywmS5Kujifvi8';
      }

      // grab the permissions based on the role name 
      //let permissons = await client.
      
      let permissions = await getPermissions(client, targetRole); 
      console.log("permissions : " + permissions)
  }

};


const getPermissions = async(client, targetRole) =>{
    let perms = await client.roles.getPermissions({id: targetRole}, function(err,permissions){
         let view_permissions = [];
            permissions.forEach((permission)=>{
                if(permission.permission_name.split(":")[0]==="view"){
                    view_permissions.push(permission.permission_name)
                }
            })
    },  Promise.resolve("blah") );
    console.log("perms : " + perms)
}


/**
* Handler that will be invoked when this action is resuming after an external redirect. If your
* onExecutePostLogin function does not perform a redirect, this function can be safely ignored.
*
* @param {Event} event - Details about the user and the context in which they are logging in.
* @param {PostLoginAPI} api - Interface whose methods can be used to change the behavior of the login.
*/
// exports.onContinuePostLogin = async (event, api) => {
// };
