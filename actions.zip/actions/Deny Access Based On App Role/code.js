/**
* Handler that will be called during the execution of a PostLogin flow.
*
* @param {Event} event - Details about the user and the context in which they are logging in.
* @param {PostLoginAPI} api - Interface whose methods can be used to change the behavior of the login.
*/
exports.onExecutePostLogin = async (event, api) => {
  // we're just going to have a logical mapping, it could be direct
  // but not worth doing quite yet
  const appName = event.client.name;
  if(appName === "CIBT Visas"){
    // check if the user has a visas_role
    let role = event.user.app_metadata['visas_role']

    if(!role){
        // the role doesn't exist for the user, deny the login
        api.access.deny("User Doesn't have Sufficent Roles (no visas role)");
    }
    

  }else if (appName === "CIBT Passports"){

    let role = event.user.app_metadata['passport_role']

    if(!role){
      api.access.deny("User has insufficent roles (no passport role)");
    }

  }
};


/**
* Handler that will be invoked when this action is resuming after an external redirect. If your
* onExecutePostLogin function does not perform a redirect, this function can be safely ignored.
*
* @param {Event} event - Details about the user and the context in which they are logging in.
* @param {PostLoginAPI} api - Interface whose methods can be used to change the behavior of the login.
*/
// exports.onContinuePostLogin = async (event, api) => {
// };
