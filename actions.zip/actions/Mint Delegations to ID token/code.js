/**
* Handler that will be called during the execution of a PostLogin flow.
*
* @param {Event} event - Details about the user and the context in which they are logging in.
* @param {PostLoginAPI} api - Interface whose methods can be used to change the behavior of the login.
*/
exports.onExecutePostLogin = async (event, api) => {
  // grab the user's email 
  const user_email = event.user.email; 

  console.log("user-email : " + user_email);

  //api.idToken.setCustomClaim("http://localhost:3000/delegations/", "test")
  // bhlaaahhhh need to make an async/await 

  try{
    let delegates = await get_delegation(user_email)
    let delegateString = JSON.stringify(delegates)

    console.log("delegate string : " + delegateString);
    api.idToken.setCustomClaim("http://localhost:3000/delegations/", delegates)
    // console.log('delegation from await : ' + delegation)
  }catch (error){
    console.log("No delegates set.")
  }
  
};

const get_delegation = async(email) =>{

  const axios = require('axios');

  const config = {
      "url":"http://1b0f-69-255-245-116.ngrok.io/get_delegate/",
      "params":{
        "delegate": email
      }
    }

  const delegates = await axios(config).then((result)=>{

    //console.log(result)

    const delegation = {
      subject: result.data.delegation.subject, 
      assumption: result.data.delegation.assumption, 
      scope: result.data.delegation.scope
    }
    //console.log(delegation)     
    return delegation; 
  })

  return delegates; 
}

/**
* Handler that will be invoked when this action is resuming after an external redirect. If your
* onExecutePostLogin function does not perform a redirect, this function can be safely ignored.
*
* @param {Event} event - Details about the user and the context in which they are logging in.
* @param {PostLoginAPI} api - Interface whose methods can be used to change the behavior of the login.
*/
// exports.onContinuePostLogin = async (event, api) => {
// };
