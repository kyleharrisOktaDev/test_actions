/**
* Handler that will be called during the execution of a PostLogin flow.
*
* @param {Event} event - Details about the user and the context in which they are logging in.
* @param {PostLoginAPI} api - Interface whose methods can be used to change the behavior of the login.
*/
exports.onExecutePostLogin = async (event, api) => {



 
  


  const MgmtClient = require('auth0').ManagementClient; 
  const client = new MgmtClient({
      domain: event.secrets.domain, 
      clientId: event.secrets.client_id, 
      clientSecret: event.secrets.client_secret
  })

  // grab the user id from the login event
 const user_id = event.user.user_id;

  // set the parameters that go into the management API function
  const params = {id: user_id, page:0, per_page:50, include_totals:false};

  // grab the permissions
  const permissions = await client.getUserPermissions(params);
  
  let permission_set = [] // init a empty array container

  // this isn't required, but filtering permissions based on the prefix so only 
  // a subset gets passed in the ID token for client side rendering. 
  permissions.forEach((permission)=>{
    let prefix = permission.permission_name.split(":")[0]
    // totally optional, really depends on business logic in the UI layer
    if(prefix==='view' || prefix === "search"){
        permission_set.push(permission.permission_name)
    }
  })

  console.log(permission_set)
  // now append the permissions to the id token using the api param 

  // grab the user's metadata permission for using app based roles


  const mintPermissionsOnRole = event.user.app_metadata.evaluate_app_roles

  if(!mintPermissionsOnRole){
    api.idToken.setCustomClaim("http://localhost:3000/permissions", permission_set)
    api.accessToken.setCustomClaim("http://localhost:3000/email", event.user.email);
  }

  // now we're done! Can be consumed in the front end.
};


/**
* Handler that will be invoked when this action is resuming after an external redirect. If your
* onExecutePostLogin function does not perform a redirect, this function can be safely ignored.
*
* @param {Event} event - Details about the user and the context in which they are logging in.
* @param {PostLoginAPI} api - Interface whose methods can be used to change the behavior of the login.
*/
// exports.onContinuePostLogin = async (event, api) => {
// };
